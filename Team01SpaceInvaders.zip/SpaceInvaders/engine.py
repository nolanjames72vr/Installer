from collections import Sequence
from typing import Optional

import pygame

from entity import Entity
from invader import Invader
from shield import Shield
from input import Input
from player import Player
from bullet import Bullet
import constants as const


INVADERS_PER_ROW = 11
INVADER_ROWS = 5

INVADER_START_Y = 78  # todo verify
INVADER_START_X = 20  # todo verify
INVADER_SPRITE_W = 16  # todo maybe change?
INVADER_SPRITE_H = 8

SHIELD_POS = [32, 192]
SHIELD_GAP = 45
SHIELD_COUNT = 4

MIN_BULLET_Y = -10

# Player spawn point
PLAYER_SPAWN_X = 100
PLAYER_SPAWN_Y = 216

class Engine:
    """
    This class controls all the game logic. It is responsible for
    setting up the game with the invaders, shields, and player. It also
    handles entity collision and the player's fire method.
    """

    def __init__(self):
        """
        Engine init method. Sets up the initial game state.
        """
        self.player = Player([PLAYER_SPAWN_X, PLAYER_SPAWN_Y])
        self.bullets = []
        self.invaders = []
        self.shields = []

        self.invader_index = 0

        self.game_over = False

        self._generate_invaders()
        self._generate_shields()

    def _generate_invaders(self) -> None:
        """
        Creates INVADER_ROWS number of rows of invaders.
        :return: None
        """
        x = INVADER_START_X
        y = INVADER_START_Y
        for row_num in range(INVADER_ROWS):
            self._generate_invader_row([x, y])
            y += const.INVADER_Y_GAP + INVADER_SPRITE_H
        self._order_invaders()

    def _order_invaders(self) -> None:
        """
        Orders invaders from by row, then column, so they update in the
        same order as the original game.
        :return: None
        """
        self.invaders.sort(
            key=lambda i: i.pos[1] * INVADERS_PER_ROW + i.pos[0],
            reverse=True
        )

    def _generate_invader_row(self, start_pos: Sequence[int]) -> None:
        """
        Creates one row of invaders that has INVADERS_PER_ROW number
        of invaders in it.
        :return: None
        """
        x = start_pos[0]
        y = start_pos[1]
        range_start = 0

        row_width = INVADER_SPRITE_W * INVADERS_PER_ROW
        # width of the area the invader has space to move within
        movement_width = const.SCREEN_SIZE[0] - row_width
        for i in range(INVADERS_PER_ROW):
            movement_range = [range_start, range_start + movement_width]
            invader = Invader([x, y], movement_range)
            self.invaders.append(invader)

            range_start += INVADER_SPRITE_W
            x += INVADER_SPRITE_W

    def _generate_shields(self) -> None:
        """
        Creates SHIELD_COUNT number of shields.
        :return: None
        """
        x = SHIELD_POS[0]
        y = SHIELD_POS[1]
        for i in range(SHIELD_COUNT):
            self.shields.append(Shield([x, y]))
            x += SHIELD_GAP

    def _get_entities(self) -> Sequence[Entity]:
        """
        :return: sequence of all entities in the game
        """
        return [self.player] + self.bullets + self.invaders \
               + self.shields

    def _update_invaders(self) -> None:
        """
        Updates all the invaders, so they move across the screen.
        :return: None
        """
        # todo make alien faster when going right if its the last one

        if len(self.invaders):
            if self.invader_index >= len(self.invaders):
                self.invader_index = 0
            invader = self.invaders[self.invader_index]
            invader.update()

            # temporary end game condition. Causes program to exit when
            # invaders the bottom.
            bottom_limit = const.SCREEN_SIZE[1] - invader.sprite.get_height()
            if invader.pos[1] > bottom_limit:
                print("game over - invader reached earth")
                self.game_over = True

            self.invader_index += 1

    @staticmethod
    def _collides(entity1: Entity, entity2: Entity) -> Optional[Sequence[int]]:
        """
        Returns where 2 entities collide. If they don't collide it
        returns None.
        :return:  coordinates of collision OR None
        """
        # todo fix - currently ignoring the player in collision checking.
        if entity1 is entity2 or isinstance(entity1, Player) or \
                isinstance(entity2, Player):
            return None

        offset = [entity2.pos[0] - entity1.pos[0],
                  entity2.pos[1] - entity1.pos[1]]
        collision_point = entity1.mask.overlap(entity2.mask, offset)
        if collision_point is None:
            return None

        return [entity1.pos[0] + collision_point[0],
                entity1.pos[1] + collision_point[1]]

    def _mng_bullet_collision(self, bullet: Bullet, entity: Entity,
                              collision_pt: Sequence[int]) -> None:
        """
         Controls the logic for what happens when a bullet collides
         with an entity.
         :return: None
         """
        if isinstance(entity, Shield):
            exp_pt = self._explosion_pt(collision_pt, bullet)
            entity.shot_explode(exp_pt, bullet.exp_img)
            self.bullets.remove(bullet)
        elif isinstance(entity, Invader) and entity.alive:
            entity.alive = False
            self.bullets.remove(bullet)

    def _detect_bullet_collisions(self) -> None:
        """
         Detects and manages all current bullet collisions.
         :return: None
         """
        bullets_to_rm = []
        for bullet in self.bullets:
            if bullet.pos[1] < MIN_BULLET_Y:
                bullets_to_rm.append(bullet)
            for entity in self._get_entities():
                collision_pt = self._collides(bullet, entity)
                if collision_pt is not None:
                    self._mng_bullet_collision(bullet, entity, collision_pt)

        for bullet in bullets_to_rm:
            self.bullets.remove(bullet)

    def _detect_invader_collisions(self) -> None:
        """
        Checks if invader is colliding with a shield or player.
        :return: None
        """
        # todo josh - check if invader is colliding with a shield or
        #  player
        pass

    def _explosion_pt(self, collision_pt: Sequence[int],
                      bullet: Bullet) -> Sequence[int]:
        """
        Calculates the position of where the explosion should damage the
        shield based on where they collide
        :return: Coordinates for where to draw the explosion
        """
        x = collision_pt[0] - bullet.exp_img.get_width() // 2
        y = collision_pt[1] - bullet.exp_img.get_height() // 2
        return x, y

    def fire_bullet(self, pos: Sequence[int],
                    direction: Bullet.BulletDirection) -> None:
        """
        Fires a bullet in a direction.
        :return: None
        """
        self.bullets.append(Bullet(pos, direction))

    def detect_collisions(self) -> None:
        """
        Calls the collision detection functions.
        :return: None
        """
        self._detect_bullet_collisions()
        self._detect_invader_collisions()

    def start(self) -> None:
        """
        Placeholder. Called when engine starts.
        :return: None
        """
        pass

    def draw(self, frame: pygame.surface) -> None:
        """
        Draws all entities to frame.
        :return: None
        """
        for entity in self._get_entities():
            entity.draw(frame)

    def update(self, cur_input: Input) -> None:
        """
        Updates game by reading the current input and calling
        appropriate entity update methods.
        :return: None
        """
        # for testing bullet
        if cur_input.fire:
            # todo fix
            pos = [self.player.pos[0] + const.PLAYER_WIDTH // 2,
                   self.player.pos[1]]
            self.bullets.append(Bullet(pos, Bullet.BulletDirection.UP))

        for bullet in self.bullets:
            bullet.update()

        self._update_invaders()

        self.detect_collisions()

        self.player.update_player(cur_input)

