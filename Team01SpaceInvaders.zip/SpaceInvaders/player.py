from entity import Entity
import constants as const
import pygame

# speed of Player in pixels/frame
PLAYER_SPEED = 2

# number of pixels to descend when invader reaches edge of screen
INVADER_FALL_SPEED = 8

class Player(Entity):
    """
    This class controls the Player entity. It is responsible for setting up
    and moving the player.
    """
    def __init__(self, pos: list):
        """
        Player init method. Sets up the player sprite.
        :param pos: x,y cordanties of the sprite
        """
        super().__init__(pos, pygame.image.load(const.Images.PLAYER))

    def update(self) -> None:
        """
        TODO
        :return: None
        """
        pass

    def update_player(self, current_input) -> None:
        """
        Moves the player left or right depending on if they are at the bounds
        and the key pressed.
        :param current_input: If the player should move left or right
        :return: None
        """
        if current_input.left and not self._at_edge(current_input):
            self.pos[0] -= PLAYER_SPEED
        elif current_input.right and not self._at_edge(current_input):
            self.pos[0] += PLAYER_SPEED

    def _at_edge(self, current_input) -> bool:
        """
        Checks if the player is at the edge of the screen.
        :param current_input: If the player is trying to move left or right.
        :return: Bool
        """
        at_edge = False
        if self.pos[0] == 0 and current_input.left:
            at_edge = True
        elif self.pos[0] == const.SCREEN_SIZE[0] - const.PLAYER_WIDTH and current_input.right:
            at_edge = True

        return at_edge
