import enum


class State(enum.Enum):
    """
    This is the game's State class that will assist in changing the
    layout of the information displayed to the user in future
    implementation.
    """

    start_menu = 1
    in_game = 2
    end_game = 3
