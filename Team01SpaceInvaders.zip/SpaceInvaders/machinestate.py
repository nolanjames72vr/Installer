from state import State


class MachineState:
    """
    This is the game's MachineState class that handles information
    regarding user information in future implementation.
    """

    def __init__(self):
        """
        Machine State init method. Variables that will be displayed
        to the user.
        """
        self.credits = 00
        self.lives = 3
        self.playerhighscore = 0000
        self.player1score = 0000
        self.player2score = 0000
