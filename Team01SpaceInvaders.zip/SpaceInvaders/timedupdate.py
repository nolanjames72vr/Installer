import math
from typing import Callable
import time


class TimedUpdate:
    """
    This class ensures an update_func is called, on average,
    updates_per_sec times per second. This effectively forces the game
    to run at a predefined speed without altering/reducing the frame
    rate.

    TimedUpdate is used by passing an update function to the constructor
    and calling the TimedUpdate function within the program's main loop.
    Each time the TimedUpdate method is called, it calculates how many
    times it needs to call the update method to ensure the update method
    is being called the predetermined number of times per second.
    """

    def __init__(self, update_func: Callable, updates_per_sec: int):
        """
        Class init function
        :param update_func: The update function that this object will
                            call
        :param updates_per_sec: The number of times per second this
                                object should call the update method
        """
        self.update_func = update_func
        self.update_interval = 1 / updates_per_sec

        self.last_update_time = None
        self.update_timer = 0

    def _get_elapsed_s(self) -> float:
        """
        :return: seconds elapsed since the update was last called
        """
        elapsed_s = time.time() - self.last_update_time
        self.last_update_time = time.time()
        return elapsed_s

    def _updates_needed(self) -> int:
        """
        :return: number of times the update function needs to be called
                 based on the amount of elapsed time
        """
        self.update_timer += self._get_elapsed_s()

        updates_needed = math.floor(self.update_timer / self.update_interval)
        self.update_timer = self.update_timer % self.update_interval
        return updates_needed

    def update(self, **kwargs) -> None:
        """
        Update method which should be called once for each time the
        screen is displayed.
        :param kwargs: optional arguments passed to the update method
        :return: None
        """
        if self.last_update_time is None:
            self.last_update_time = time.time()

        for i in range(self._updates_needed()):
            self.update_func(**kwargs)
