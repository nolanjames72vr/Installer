from entity import Entity
import pygame


class Saucer(Entity):
    """
    This class is controls the Saucer entity. It is responsible for setting up and
    moving the saucer.
    """


    def __init__(self, pos: list):
        """
        Saucer init method. Sets up the saucer when it is first spawned.
        :param pos: x,y position of the sprite.
        """
        # todo add image
        super().__init__(pos, None)

    def update(self) -> None:
        """
        updates the saucer's position on screen.
        :return: None
        """
        # TODO add - add movement
        pass

    def draw(self, frame: pygame.surface) -> None:
        """
        Saucer init method. Sets up the saucer when it is first spawned.
        TODO
        :return: None
        """
        pass
