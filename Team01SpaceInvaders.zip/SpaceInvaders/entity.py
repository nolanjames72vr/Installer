from abc import ABC, abstractmethod
import pygame


class Entity(ABC):
    """
    Entity is an abstract class that represents entities in the game
    """
    def __init__(self, pos: list, sprite: pygame.Surface):
        """
        Entity init method. Sets up the entity.
        :param pos: x,y position of the sprite.
        :param sprite: sprite to be used.
        """
        self.sprite = sprite
        self.pos = pos
        self.mask = pygame.mask.from_surface(self.sprite)

    @abstractmethod
    def update(self) -> None:
        """
        Abstract update method that is called continuously.
        :return: None
        """
        pass

    def draw(self, frame: pygame.surface) -> None:
        """
        Draws the sprite into the frame.
        :param frame: Frame the sprite is being drawn onto.
        :return: None
        """
        frame.blit(self.sprite, self.pos)
