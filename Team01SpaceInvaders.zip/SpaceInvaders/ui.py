import pygame
import constants as const
from machinestate import MachineState
from typing import Sequence

# coordinates for placing game text
FONT_SIZE = 10
MENU_DIVISOR = 2
MENU_POSITION_X = 75
MENU_POSITION_X1 = 220
MENU_POSITION_X2 = 380
MENU_POSITION_X3 = 350
MENU_POSITION_X4 = 400

MENU_POSITION_Y = 20
MENU_POSITION_Y1 = 50
MENU_POSITION_Y9 = 480

class UI:
    """
    This is the game's UI class that handles displaying information to
    the user through methods that draw and update the frame.
    """

    def __init__(self):
        """
        UI init method. Sets up the variables that will be displayed to
        the user.
        """
        self.player1score = 0000
        self.playerhighscore = 0000
        self.player2score = 0000
        self.lives = 3
        self.credits = 00

    def _write_text(self, frame: pygame.Surface, text: str,
                    posx: Sequence[int], posy: Sequence[int]) -> None:
        """
        Write_Text Method, which formats and displays the game text.
        :param frame: The location the game text is drawn to.
        :param text: The game text to be displayed.
        :param posx: The X location of the text.
        :param posy: The Y location of the text.
        :return: None
        """
        font = pygame.font.SysFont("arial", FONT_SIZE)
        label = font.render(str(text), True, const.WHITE, const.BLACK)
        labelbox = label.get_rect()
        labelbox.center = (posx // MENU_DIVISOR,
                           posy // MENU_DIVISOR)
        frame.blit(label, labelbox)

    def draw(self, frame: pygame.surface) -> None:
        """
        Draw Method, which calls a method to draw the game text to
        the frame.
        :param frame: The location the game text is drawn to.
        :return: None
        """
        self._write_text(frame, 'SCORE<1>', MENU_POSITION_X,
                         MENU_POSITION_Y)
        self._write_text(frame, str(self.player1score), MENU_POSITION_X,
                         MENU_POSITION_Y1)
        self._write_text(frame, 'HI-SCORE', MENU_POSITION_X1,
                         MENU_POSITION_Y)
        self._write_text(frame, str(self.playerhighscore),
                         MENU_POSITION_X1, MENU_POSITION_Y1)
        self._write_text(frame, 'SCORE<2>', MENU_POSITION_X2,
                         MENU_POSITION_Y)
        self._write_text(frame, str(self.player2score),
                         MENU_POSITION_X2, MENU_POSITION_Y1)
        self._write_text(frame, str(self.lives), MENU_POSITION_X,
                         MENU_POSITION_Y9)
        self._write_text(frame, 'CREDIT', MENU_POSITION_X3,
                         MENU_POSITION_Y9)
        self._write_text(frame, str(self.credits), MENU_POSITION_X4,
                         MENU_POSITION_Y9)

    def update(self, machinestate: MachineState) -> None:
        """
        Update method, which must be called every frame. This method
        updates the MachineState variables.
        :param machinestate: Variables that are displayed to the user.
        :return: None
        """
        self.player1score = machinestate.player1score
        self.playerhighscore = machinestate.playerhighscore
        self.player2score = machinestate.player2score
        self.lives = machinestate.lives
        self.credits = machinestate.credits
