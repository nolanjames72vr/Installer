from entity import Entity
import constants as const
import pygame
from enum import Enum

# speed of invader in pixels/frame
INVADER_SPEED = 2

INVADER_FALL_SPEED = 8
class Invader(Entity):
    """
    This class controls the Invader entity. It is responsible for setting up
    and moving the invader.
    """
    class InvaderDirection(Enum):
        LEFT = -1
        RIGHT = 1

    def __init__(self, pos: list, movement_range: list):
        """
        Invader init method. Sets up the invader sprite.
        :param pos: x,y position of the sprite.
        :param movement_range: range that the sprite can move.
        """
        super().__init__(pos, pygame.image.load(const.Images.INVADER1))
        self.x_direction = Invader.InvaderDirection.RIGHT
        self.movement_range = movement_range
        self.sprite = pygame.image.load(const.Images.INVADER1)
        self.just_switched_direction = False
        self.alive = True

    def _is_outside_range(self) -> bool:
        """
        Checks if the invader is outside its movement range.
        :return: bool
        """
        return self.pos[0] < self.movement_range[0] \
               or self.pos[0] > self.movement_range[1]

    def _switch_direction(self) -> None:
        """
        Switches the direction of the invader.
        :return: None
        """
        self.pos[1] += INVADER_FALL_SPEED

        if self.x_direction == Invader.InvaderDirection.LEFT:
            self.x_direction = Invader.InvaderDirection.RIGHT
        else:
            self.x_direction = Invader.InvaderDirection.LEFT

        self.just_switched_direction = True

    def update(self) -> None:
        """
        checks if the invader needs to switch movement direction then moves
        the invader if it does not need to switch direction.
        :return: None
        """
        if self._is_outside_range() and not self.just_switched_direction:
            self._switch_direction()
        else:
            self.pos[0] += self.x_direction.value * INVADER_SPEED
            # print(self.x_direction.value * const.INVADER_SPEED)
            self.just_switched_direction = False

    def draw(self, frame: pygame.surface) -> None:
        """
        If the invader is still alive it moves its position on screen.
        :param frame: Frame the sprite is being drawn onto.
        :return: None
        """
        if self.alive:
            frame.blit(self.sprite, self.pos)
