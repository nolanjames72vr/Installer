import pygame


class Keys:

    LEFT = pygame.K_a
    RIGHT = pygame.K_d

    START1 = pygame.K_1
    START2 = pygame.K_2
    FIRE = pygame.K_j
    COIN = pygame.K_5
    TILT = pygame.K_t

    # todo figure out what keys we need to assign.
    #  I copied the keys used in the si78c repo
    DIP6 = 128
    DIP7 = 256
    SPECIAL1 = 512
    SPECIAL2 = 1024
    QUIT = 2048


class Images:

    BULLET = "bullet.png"
    INVADER1 = "invader1_1.png"
    PLAYER = "player.png"
    SHIELD = "shield.png"
    INVADER_SHOT_EXPL = "AShotExplo.png"


BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
TRANSPARENT = (0, 0, 0, 0)

SCREEN_SIZE = (224, 256)
SCALE = 2

INVADER_X_GAP = 0  # verified correct
INVADER_Y_GAP = 8  # verified correct


INVADER_ROW_WIDTH = 172





# Player size
PLAYER_WIDTH = 16
PLAYER_HEIGHT = 8


