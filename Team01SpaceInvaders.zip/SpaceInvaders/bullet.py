from entity import Entity
import constants as const
from enum import Enum
from typing import Sequence
import pygame

# speed of bullets in pixels/frame
BULLET_SPEED = 1

class Bullet(Entity):
    """
    This class controls the Bullet entity. It is responsible for setting up
    and moving the bullet.
    """
    class BulletDirection(Enum):
        DOWN = 1
        UP = -1

    def __init__(self, pos: Sequence[int], direction: BulletDirection):
        """
        Bullet init method. Sets up the bullet sprite.
        :param pos: x,y position of the sprite
        :param direction: direction that the sprite will move.
        """
        super().__init__(pos, pygame.image.load(const.Images.BULLET))
        self.direction = direction
        self.collide_rect = None
        self.exp_img = pygame.image.load(const.Images.INVADER_SHOT_EXPL)

    def update(self) -> None:
        """
        Moves the bullet sprite.
        :return: None
        """
        self.pos[1] += self.direction.value * BULLET_SPEED


    def draw(self, frame: pygame.surface) -> None:
        """
        Draws the sprite onto a frame.
        :param frame: Frame the sprite is being drawn to
        :return: None
        """
        frame.blit(self.sprite, self.pos)
