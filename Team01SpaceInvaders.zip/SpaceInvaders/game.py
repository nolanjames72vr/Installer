import pygame
import constants as const
from machinestate import MachineState
from timedupdate import TimedUpdate
from ui import UI
from engine import Engine
from input import Input
from typing import Sequence

# the number of times the update function should be called per sec
UPDATES_P_SEC = 60

class Game:
    """
    This is the game's base class that link's the user interface with
    the game's engine. It also will maintain the game machine's state,
    which includes high scores and the number of coins currently in the
    machine.
    """

    def __init__(self):
        """
        Game init method. Sets up the Engine and UI.
        """
        pygame.init()
        self.window = pygame.display.set_mode(self._calc_window_size())
        pygame.display.set_caption('Space Invaders')
        self.frame = pygame.Surface(const.SCREEN_SIZE)
        self.ui = UI()
        self.engine = Engine()
        self.running = True

        self.machine_state = MachineState()
        self.engine_updater = TimedUpdate(self._update, UPDATES_P_SEC)

    def run(self) -> None:
        """
        Begins running the game
        :return: None
        """
        self.engine.start()

        while self.running:
            self.main_loop()
        self._exit()

    def main_loop(self) -> None:
        """
        The game's main loop. Updates the engine and UI, then draws it
        to the screen.
        :return: None
        """
        self.engine_updater.update()
        self.ui.update(self.machine_state)
        self._draw()

    @staticmethod
    def _calc_window_size() -> Sequence[int]:
        """
        Static method for calculating the window size based on the
        current scale value
        :return: The size of the window in pixels.
        """
        return [i * const.SCALE for i in const.SCREEN_SIZE]

    def _update(self) -> None:
        """
        Update method, which must be called every frame. This method
        gathers user input and sends it to the engine and UI while
        calling their update methods.
        :return: None
        """
        cur_input = Input.get_input()

        if cur_input.quit or self.engine.game_over:
            self.running = False
        else:
            self.engine.update(cur_input)
            self.ui.update(self.machine_state)

    def _draw(self) -> None:
        """
        Draws a frame by clearing the frame, drawing the engine and UI,
        and scaling the frame to the screen size.
        :return: None
        """
        self._clear_frame()

        self.engine.draw(self.frame)
        self.ui.draw(self.frame)

        scaled = pygame.transform.scale(self.frame, self._calc_window_size())
        self.window.blit(scaled, scaled.get_rect())
        pygame.display.flip()

    def _clear_frame(self) -> None:
        """
        Clears frame
        :return: None
        """
        self.frame.fill(const.BLACK)

    @staticmethod
    def _exit() -> None:
        """
        Must be called when program exits.
        :return: None
        """
        pygame.display.quit()
