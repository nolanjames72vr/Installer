import pygame
import constants as const


class Input:
    """
    The Input class is used to collect user input and store it in an
    easily accessible format. Other classes should only gather user
    through use of the input class
    """

    def __init__(self):
        """
        Input init method. Initializes all inputs to false
        """
        # whether key is currently pressed
        self.left = False
        self.right = False

        # whether key was just pressed
        # (meaning key transitioned from up to down)
        self.start1 = False
        self.start2 = False
        self.fire = False
        self.coin = False
        self.tilt = False

        # whether the user requested the program exit
        self.quit = False

    def _process_keydown(self, keydown_event: pygame.event) -> None:
        """
        Determines if a keydown is relevant to the game's input. If it
        is, then alter the relevant input value based on which key is
        pressed.
        :param keydown_event: a keydown event
        :return: None
        """
        if keydown_event.key == const.Keys.START1:
            self.start1 = True
        elif keydown_event.key == const.Keys.START2:
            self.start2 = True
        elif keydown_event.key == const.Keys.FIRE:
            self.fire = True
        elif keydown_event.key == const.Keys.COIN:
            self.coin = True
        elif keydown_event.key == const.Keys.TILT:
            self.tilt = True

    def _process_keys_pressed(self) -> None:
        """
        Determine if the keys currently pressed are relevant to the
        game's input. If it is, then alter the relevant input value
        based on which key is pressed.
        :return: None
        """
        keys_pressed = pygame.key.get_pressed()
        if keys_pressed[const.Keys.LEFT]:
            self.left = True
        if keys_pressed[const.Keys.RIGHT]:
            self.right = True

    @staticmethod
    def get_input():
        """
        Static method used for generating input object based on the
        games current input.
        :return: Input object based on current game input
        """
        i = Input()
        i._process_keys_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                i.quit = True
            elif event.type == pygame.KEYDOWN:
                i._process_keydown(event)
        return i

    def __str__(self) -> str:
        """
        :return: String representation of Input object
        """
        return f"Left: {self.left}, Right: {self.right}, " \
               f"Start1: {self.start1}, Start2: {self.start2}, " \
               f"Fire: {self.fire}, Coin: {self.coin}, " \
               f"Tilt: {self.tilt}"

    def __repr__(self) -> str:
        """
        :return: String representation of Input object
        """
        return self.__str__()
